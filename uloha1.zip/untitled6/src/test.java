import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.awt.*;

import static javafx.scene.paint.Color.*;

public class test extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        Group root = new Group();

        // vytvorenie scény definovaním root a rozmerov
        Scene scene = new Scene(root ,550, 200);

        // nastavenie farby scény
        scene.setFill(BLACK);
        // nastavenie titulku okna
        stage.setTitle("Moja FX aplikácia");

        DropShadow shadow = new DropShadow();
        shadow.setColor(CYAN);
        DropShadow shadow1 = new DropShadow();
        shadow1.setColor(RED);
        DropShadow shadow2 = new DropShadow();
        shadow2.setColor(GREEN);
        DropShadow shadow3 = new DropShadow();
        shadow3.setColor(VIOLET);
        DropShadow shadow4 = new DropShadow();
        shadow4.setColor(YELLOW);




        Line line1 = new Line(70,70,110,70);
        Line line2 = new Line(110,70,100,80);
        Line line3 = new Line(70,70,110,110);
        Line line4 = new Line(70,110,110,110);
        Line line5 = new Line(70,110,80,100);
// zafarbenie
        line1.setStroke(VIOLET);
        line2.setStroke(VIOLET);
        line3.setStroke(VIOLET);
        line4.setStroke(VIOLET);
        line5.setStroke(VIOLET);

        line1.setStrokeWidth(3);
        line2.setStrokeWidth(3);
        line3.setStrokeWidth(3);
        line4.setStrokeWidth(3);
        line5.setStrokeWidth(3);

        line1.setEffect(shadow3);
        line2.setEffect(shadow3);
        line3.setEffect(shadow3);
        line4.setEffect(shadow3);
        line5.setEffect(shadow3);

// vloženie
        root.getChildren().add(line1);
        root.getChildren().add(line2);
        root.getChildren().add(line3);
        root.getChildren().add(line4);
        root.getChildren().add(line5);


        Line line11 = new Line(150,70,190,70);
        Line line12 = new Line(190,70,185,80);
        Line line13 = new Line(150,70,170,110);
        Line line14 = new Line(170,110,178,95);
        Line line15 = new Line(175,80,185,80);
// zafarbenie
        line11.setStroke(YELLOW);
        line12.setStroke(YELLOW);
        line13.setStroke(YELLOW);
        line14.setStroke(YELLOW);
        line15.setStroke(YELLOW);

        line11.setStrokeWidth(3);
        line12.setStrokeWidth(3);
        line13.setStrokeWidth(3);
        line14.setStrokeWidth(3);
        line15.setStrokeWidth(3);

        line11.setEffect(shadow4);
        line12.setEffect(shadow4);
        line13.setEffect(shadow4);
        line14.setEffect(shadow4);
        line15.setEffect(shadow4);

// vloženie
        root.getChildren().add(line11);
        root.getChildren().add(line12);
        root.getChildren().add(line13);
        root.getChildren().add(line14);
        root.getChildren().add(line15);

        Line line21 = new Line(250,70,230,110);
        Line line22 = new Line(260,90,270,110);
        Line line23 = new Line(230,110,270,110);

// zafarbenie
        line21.setStroke(RED);
        line22.setStroke(RED);
        line23.setStroke(RED);


        line21.setStrokeWidth(3);
        line22.setStrokeWidth(3);
        line23.setStrokeWidth(3);

        line21.setEffect(shadow1);
        line22.setEffect(shadow1);
        line23.setEffect(shadow1);



// vloženie
        root.getChildren().add(line21);
        root.getChildren().add(line22);
        root.getChildren().add(line23);

        Line line31 = new Line(330,70,350,110);
        Line line32 = new Line(350,110,365,85);
        Line line33 = new Line(330,70,370,70);

// zafarbenie
        line31.setStroke(GREEN);
        line32.setStroke(GREEN);
        line33.setStroke(GREEN);


        line31.setStrokeWidth(3);
        line32.setStrokeWidth(3);
        line33.setStrokeWidth(3);

        line31.setEffect(shadow2);
        line32.setEffect(shadow2);
        line33.setEffect(shadow2);



// vloženie
        root.getChildren().add(line31);
        root.getChildren().add(line32);
        root.getChildren().add(line33);


        Line line41 = new Line(410,110,450,110);
        Line line42 = new Line(410,110,415,100);
        Line line43 = new Line(422,85,430,70);
        Line line44 = new Line(430,70,450,110);
        Line line45 = new Line(415,100,425,100);
// zafarbenie
        line41.setStroke(CYAN);
        line42.setStroke(CYAN);
        line43.setStroke(CYAN);
        line44.setStroke(CYAN);
        line45.setStroke(CYAN);


        line41.setStrokeWidth(3);
        line42.setStrokeWidth(3);
        line43.setStrokeWidth(3);
        line44.setStrokeWidth(3);
        line45.setStrokeWidth(3);

        line41.setEffect(shadow);
        line42.setEffect(shadow);
        line43.setEffect(shadow);
        line44.setEffect(shadow);
        line45.setEffect(shadow);

// vloženie
        root.getChildren().add(line41);
        root.getChildren().add(line42);
        root.getChildren().add(line43);
        root.getChildren().add(line44);
        root.getChildren().add(line45);




        // pridanie scény do stage, rozmer sa prispôsobí
        stage.setScene(scene);
        stage.show(); // zobrazenie obsahu
    }

    public static void main(String[] args) {
        launch(args);
    }
}



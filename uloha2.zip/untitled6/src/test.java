import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.util.Scanner;

import java.awt.*;

import static javafx.scene.paint.Color.*;

public class test extends Application {

    Scanner vstup =new Scanner(System.in);
    String s =vstup.nextLine();

    public static int pocet_samohlasky(String s)
    {
        int samo = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s.charAt(i) == 'a' || s.charAt(i) == 'e' || s.charAt(i) == 'i'
                    || s.charAt(i) == 'o' || s.charAt(i) == 'u')
            {
                samo++;
            }
        }
        return samo;
    }

    public static int pocet_spoluhlasky(String s)
    {
        int spolu = 0;
        for (int i = 0; i < s.length(); i++)
        {
            if (s.charAt(i) == 'd' || s.charAt(i) == 't' || s.charAt(i) == 'n'
                    || s.charAt(i) == 'l' || s.charAt(i) == 'h' || s.charAt(i) == 'g'
                    || s.charAt(i) == 'k')
            {
                spolu++;
            }
        }
        return spolu;
    }

    int r = pocet_samohlasky(s) * 16;
    int g = pocet_spoluhlasky(s) * 24;
    int b = (s.length() % 25) * 10;



    @Override
    public void start(Stage stage) throws Exception {

        Group root = new Group();

        // vytvorenie scény definovaním root a rozmerov
        Scene scene = new Scene(root ,(s.length())*40, 150);

        // nastavenie farby scény
        scene.setFill(rgb(r,g,b));
        // nastavenie titulku okna
        stage.setTitle("Moja FX aplikácia");

        Text text = new Text(50, 100, s);
        text.setFont(Font.font("Tahoma" , 60));
        text.setStroke(Color.GREEN); // obrys
        text.setFill(Color.RED);   // vypln

        root.getChildren().add(text);




        // pridanie scény do stage, rozmer sa prispôsobí
        stage.setScene(scene);
        stage.show(); // zobrazenie obsahu
    }

    public static void main(String[] args) {

        launch(args);
    }
}



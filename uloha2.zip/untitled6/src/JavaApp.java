import java.util.Scanner;

public class JavaApp extends test {
    public static void main(String[] args) {


        String s;
        char ch;
        char ch2;
         int samo=0;
         int spolu=0;
        Scanner sc=new Scanner(System.in);

        s=sc.nextLine();
        for(int j=0;j<s.length();j++)
        {
            ch=s.charAt(j);
            switch(ch)
            {
                case 'a'  :
                case 'e'  :
                case 'i'  :
                case 'o'  :
                case 'u'  :
                case 'A'  :
                case 'E'  :
                case 'I'  :
                case 'O'  :
                case 'U'  :samo++;
                   // System.out.println(ch);

            }
        }

        for(int h=0;h<s.length();h++)
        {
            ch2=s.charAt(h);
            switch(ch2)
            {
                case 'd'  :
                case 't'  :
                case 'n'  :
                case 'l'  :
                case 'h'  :
                case 'g'  :
                case 'k'  :
                case 'D'  :
                case 'T'  :
                case 'N'  :
                case 'L'  :
                case 'H'  :
                case 'G'  :
                case 'K'  :spolu++;
                    // System.out.println(ch);

            }
        }

        //System.out.println(samo);
        //System.out.println(spolu);

        }
    }

